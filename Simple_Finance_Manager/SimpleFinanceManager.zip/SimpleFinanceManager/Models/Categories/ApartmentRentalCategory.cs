﻿public class ApartmentRentalCategory : Category
{
    public ApartmentRentalCategory(string name) : base(name)
    {
    }
}