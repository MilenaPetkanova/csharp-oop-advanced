﻿public class BillsCategory : Category
{
    public BillsCategory(string name) : base(name)
    {
    }
}