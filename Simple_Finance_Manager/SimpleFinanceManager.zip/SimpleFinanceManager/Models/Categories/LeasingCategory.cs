﻿public class LeasingCategory : Category
{
    public LeasingCategory(string name) : base(name)
    {
    }
}