﻿public class GroceriesCategory : Category
{
    public GroceriesCategory(string name) : base(name)
    {
    }
}