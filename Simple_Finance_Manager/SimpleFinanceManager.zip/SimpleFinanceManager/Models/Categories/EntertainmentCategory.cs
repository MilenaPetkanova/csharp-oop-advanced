﻿public class EntertainmentCategory : Category
{
    public EntertainmentCategory(string name) : base(name)
    {
    }
}