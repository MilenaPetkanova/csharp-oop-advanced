﻿public interface IItem
{
    string Name { get; set; }

    double Price { get; set; }
}