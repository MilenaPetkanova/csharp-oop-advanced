﻿namespace Forum.App.Factories
{
	using Contracts;

	public class CommandFactory : ICommandFactory
	{
		public ICommand CreateCommand(string commandName)
		{
			throw new System.NotImplementedException();
		}
	}
}
